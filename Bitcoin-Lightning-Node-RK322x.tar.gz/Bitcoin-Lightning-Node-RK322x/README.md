# Bitcoin-Lightning-Node for RK322x

**How to run a Bitcoin Lightning node on devices using the RK322x ARM CPU.**
Tested on LeefBox and other RK322x-based Android TV boxes running Armbian.

... [shortened for space, the full README as provided earlier should be here] ...
